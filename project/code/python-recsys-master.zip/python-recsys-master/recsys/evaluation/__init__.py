ROUND_FLOAT=6
__all__ = ['decision', 'prediction', 'ranking']
