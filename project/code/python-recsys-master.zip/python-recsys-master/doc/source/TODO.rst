TODO
=====

* divisi2.make_sparse is way too slow! Need to change the way how the matrix is created

* Too much memory consumption using divisi2 functions. Remove dependencies from divisi2?

* algorithms: Gradient Descent rsvd?

* evaluation: add DCG

* switch to Pycluster to compute kmeans? http://pypi.python.org/pypi/Pycluster 

* Mention other Python approaches somewhere in the documentation:

  * pysuggest http://code.google.com/p/pysuggest/

  * pyrsvd http://code.google.com/p/pyrsvd/

  * crab https://github.com/marcelcaraciolo/crab

  * pyflix http://pyflix.python-hosting.com/

