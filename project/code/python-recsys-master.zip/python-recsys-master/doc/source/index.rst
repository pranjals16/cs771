.. SVD Recommender documentation master file, created by
   sphinx-quickstart on Thu Dec  2 23:29:15 2010.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

python-recsys Library
=====================

.. toctree::
   :maxdepth: 2

   installation
   quickstart
   datamodel
   algorithm
   evaluation
   examples
   api
   tests
   TODO

   :ref:`modindex`

:Authors: 
    Oscar Celma

:Version: 0.1 (2011/10/06)
